package com.example.wordgameclean.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.wordgameclean.ui.theme.GameTheme
import com.example.wordgameclean.ui.theme.ThemeDefaults
import com.example.wordgameclean.ui.theme.ThemeManager

class ThemeSettingsActivity : AppCompatActivity() {

    private lateinit var themeManager: ThemeManager
    private lateinit var previewContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        themeManager = ThemeManager(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "Выберите тему"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        root.addView(title)

        previewContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(previewContainer)

        val saveBtn = Button(this).apply {
            text = "Сохранить и вернуться"
            setOnClickListener {
                finish()
            }
        }
        root.addView(saveBtn)

        setContentView(root)

        loadThemes()
    }

    private fun loadThemes() {
        previewContainer.removeAllViews()

        for (theme in themeManager.getAllThemes()) {
            val themeCard = createThemeCard(theme)
            previewContainer.addView(themeCard)

            // Добавляем разделитель
            val divider = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1
                ).apply {
                    topMargin = 16
                    bottomMargin = 16
                }
                setBackgroundColor(Color.parseColor("#DDDDDD"))
            }
            previewContainer.addView(divider)
        }
    }

    private fun createThemeCard(theme: GameTheme): LinearLayout {
        val isSelected = themeManager.currentTheme.name == theme.name

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 16, 16, 16)

            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 16f
                if (isSelected) {
                    setStroke(4, Color.parseColor("#4CAF50"))
                } else {
                    setStroke(1, Color.parseColor("#DDDDDD"))
                }
            }

            setOnClickListener {
                themeManager.currentTheme = theme
                loadThemes() // перезагружаем для обновления выделения
                Toast.makeText(context, "Тема: ${theme.name}", Toast.LENGTH_SHORT).show()
            }

            // Превью
            val preview = createPreview(theme)
            addView(preview)

            // Название
            val nameText = TextView(context).apply {
                text = theme.name
                textSize = 18f
                setPadding(16, 0, 0, 0)
            }
            addView(nameText)

            // Галочка если выбрана
            if (isSelected) {
                val checkmark = TextView(context).apply {
                    text = "✓"
                    textSize = 24f
                    setTextColor(Color.parseColor("#4CAF50"))
                    setPadding(16, 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                    ).apply {
                        gravity = Gravity.END
                    }
                }
                addView(checkmark)
            }
        }
    }

    private fun createPreview(theme: GameTheme): View {
        return TextView(this).apply {
            text = "Aa"
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(32, 16, 32, 16)

            background = GradientDrawable().apply {
                setColor(theme.buttonColor)
                cornerRadius = 24f
            }
            setTextColor(theme.buttonTextColor)
        }
    }
}