package com.example.wordgameclean.ui.theme

import android.graphics.Color

data class GameTheme(
    val name: String,
    val backgroundColor: Int,
    val wordContainerBg: Int,
    val keyboardBg: Int,
    val buttonColor: Int,
    val buttonTextColor: Int,
    val scoreTextColor: Int,
    val actionIndicatorColor: Int,
    val letterBgColor: Int,
    val letterStrokeColor: Int
)

object ThemeDefaults {
    val CLASSIC = GameTheme(
        name = "Классическая",
        backgroundColor = Color.WHITE,
        wordContainerBg = Color.parseColor("#F5F5F5"),
        keyboardBg = Color.parseColor("#FAFAFA"),
        buttonColor = Color.parseColor("#3F51B5"),
        buttonTextColor = Color.WHITE,
        scoreTextColor = Color.BLACK,
        actionIndicatorColor = Color.DKGRAY,
        letterBgColor = Color.parseColor("#F5F5F5"),
        letterStrokeColor = Color.parseColor("#CCCCCC")
    )

    val DARK = GameTheme(
        name = "Тёмная",
        backgroundColor = Color.parseColor("#121212"),
        wordContainerBg = Color.parseColor("#1E1E1E"),
        keyboardBg = Color.parseColor("#2C2C2C"),
        buttonColor = Color.parseColor("#BB86FC"),
        buttonTextColor = Color.WHITE,
        scoreTextColor = Color.parseColor("#E0E0E0"),
        actionIndicatorColor = Color.parseColor("#AAAAAA"),
        letterBgColor = Color.parseColor("#333333"),
        letterStrokeColor = Color.parseColor("#555555")
    )

    val NATURE = GameTheme(
        name = "Природная",
        backgroundColor = Color.parseColor("#E8F5E9"),
        wordContainerBg = Color.parseColor("#FFF9C4"),
        keyboardBg = Color.parseColor("#C8E6C9"),
        buttonColor = Color.parseColor("#4CAF50"),
        buttonTextColor = Color.WHITE,
        scoreTextColor = Color.parseColor("#2E7D32"),
        actionIndicatorColor = Color.parseColor("#388E3C"),
        letterBgColor = Color.parseColor("#FFF9C4"),
        letterStrokeColor = Color.parseColor("#81C784")
    )
}