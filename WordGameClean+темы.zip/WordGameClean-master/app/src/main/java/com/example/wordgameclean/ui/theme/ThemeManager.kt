package com.example.wordgameclean.ui.theme

import android.content.Context

class ThemeManager(context: Context) {

    private val prefs = context.getSharedPreferences("theme_settings", Context.MODE_PRIVATE)

    var currentTheme: GameTheme
        get() {
            val themeName = prefs.getString("current_theme", "classic") ?: "classic"
            return when (themeName) {
                "dark" -> ThemeDefaults.DARK
                "nature" -> ThemeDefaults.NATURE
                else -> ThemeDefaults.CLASSIC
            }
        }
        set(theme) {
            val key = when (theme) {
                ThemeDefaults.DARK -> "dark"
                ThemeDefaults.NATURE -> "nature"
                else -> "classic"
            }
            prefs.edit().putString("current_theme", key).apply()
        }

    fun getAllThemes(): List<GameTheme> {
        return listOf(ThemeDefaults.CLASSIC, ThemeDefaults.DARK, ThemeDefaults.NATURE)
    }
}